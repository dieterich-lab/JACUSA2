package test.utlis;

public interface SAMRecordBuilderStrategy {

	void useStrategy(String contig, SAMRecordBuilder builder);
	
}
