package test.lib.data.validator.paralleldata;

import static org.junit.jupiter.api.Assertions.*;

class LRTarrestVariantParallelPileupTest {

	// @Test
	// TODO Qi (advanced) check LRTarrestVariantParallelPileup test that isValid is true only when  
	// at a site there are read through AND read arrest events
	void testIsValid() {
		fail("Not yet implemented"); // TODO
	}

}
