source("createPhred2Prob.R")

myWrite(createColSumErrorProb(), "dataColSumErrorProb.csv")