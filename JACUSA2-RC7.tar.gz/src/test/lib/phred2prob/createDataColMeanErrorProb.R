source("createPhred2Prob.R")

myWrite(createColMeanErrorProb(), "dataColMeanErrorProb.csv")