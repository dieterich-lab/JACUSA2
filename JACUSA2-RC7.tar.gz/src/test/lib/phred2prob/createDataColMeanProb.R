source("createPhred2Prob.R")

myWrite(createColMeanProb(), "dataColMeanProb.csv")