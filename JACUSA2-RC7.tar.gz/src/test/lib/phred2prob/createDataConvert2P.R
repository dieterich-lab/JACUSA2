source("createPhred2Prob.R")

myWriteWrapper(createP(), "dataConvert2P.csv")