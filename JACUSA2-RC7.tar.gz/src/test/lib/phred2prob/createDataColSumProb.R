source("createPhred2Prob.R")

myWrite(createColSumProb(), "dataColSumProb.csv")