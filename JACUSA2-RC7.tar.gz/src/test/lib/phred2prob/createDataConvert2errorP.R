source("createPhred2Prob.R")

myWriteWrapper(createErrorP(), "dataConvert2errorP.csv")