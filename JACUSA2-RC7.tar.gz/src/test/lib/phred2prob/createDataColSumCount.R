source("createPhred2Prob.R")

myWrite(createColSumCount(), "dataColSumCount.csv")