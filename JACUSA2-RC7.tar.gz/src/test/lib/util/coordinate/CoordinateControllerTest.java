package test.lib.util.coordinate;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

@Disabled("TODO")
class CoordinateControllerTest {

	// private CoordinateController testInstance;
	
	@Test
	void testCoordinateController() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testUpdateReserved() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testHasNext() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testNext() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testGetActive() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testGetReserved() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testIsInner() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testIsLeft() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testIsRight() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testAdvance() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testGetCoordinateAdvancer() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testGetActiveWindowSize() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testCheckCoordinateWithinActiveWindow() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testCheckCoordinateAdvancerWithinActiveWindow() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testChechWindowPositionWithinActiveWindow() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testConvert2windowPositionCoordinate() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testConvert2windowPositionInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testConvert2referencePosition() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testGetStrandedWindowPosition() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testGetSharedStorage() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testGetReferenceProvider() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testConvertIntInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testConvertIntIntInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	void testToString() {
		fail("Not yet implemented"); // TODO
	}

}
