package lib.util;

public interface Builder<T> {

	T build();
	
}
