package lib.data.validator;

import lib.util.position.Position;

public interface Validator {
	
	boolean isValid(Position pos);
	
}
