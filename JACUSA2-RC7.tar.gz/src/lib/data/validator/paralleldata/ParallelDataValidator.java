package lib.data.validator.paralleldata;

import lib.data.ParallelData;

public interface ParallelDataValidator  {
	
	boolean isValid(final ParallelData parallelData);
	
}
