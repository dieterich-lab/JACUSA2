package lib.data.has;

import lib.util.coordinate.Coordinate;

/**
 * 
 * 
 *
 */
public interface HasCoordinate {

	Coordinate getCoordinate();
	
}
