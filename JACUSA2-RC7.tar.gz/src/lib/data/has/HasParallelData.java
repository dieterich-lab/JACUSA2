package lib.data.has;

import lib.data.ParallelData;

public interface HasParallelData {

	ParallelData getParellelData();
	
}
