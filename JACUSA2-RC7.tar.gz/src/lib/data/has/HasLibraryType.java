package lib.data.has;

import lib.util.LibraryType;

public interface HasLibraryType {

	LibraryType getLibraryType();
	
}
