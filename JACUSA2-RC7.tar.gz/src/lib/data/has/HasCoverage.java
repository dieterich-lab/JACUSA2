package lib.data.has;

public interface HasCoverage {

	int getCoverage();
	
}
