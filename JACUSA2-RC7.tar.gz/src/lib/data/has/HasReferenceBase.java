package lib.data.has;

import lib.util.Base;

/**
 * 
 * 
 *
 */
public interface HasReferenceBase {

	Base getReferenceBase();

}
