package lib.data.storage;

public interface WindowCoverage {

	int getCoverage(int winPos);
	
}
