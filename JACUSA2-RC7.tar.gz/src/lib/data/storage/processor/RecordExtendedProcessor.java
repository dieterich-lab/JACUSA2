package lib.data.storage.processor;

import lib.recordextended.SAMRecordExtended;

public interface RecordExtendedProcessor {

	void process(SAMRecordExtended recordExtended);
	
}
