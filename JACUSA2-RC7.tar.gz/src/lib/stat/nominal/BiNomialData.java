package lib.stat.nominal;

public class BiNomialData extends AbstractNominalData {

	BiNomialData(final int categories, final double[][] data) {
		super(categories, data);
	}
	
}
