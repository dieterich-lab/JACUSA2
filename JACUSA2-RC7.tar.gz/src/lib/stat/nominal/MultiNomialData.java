package lib.stat.nominal;

public class MultiNomialData extends AbstractNominalData {

	MultiNomialData(final int categories, final double[][] data) {
		super(categories, data);
	}
	
}
