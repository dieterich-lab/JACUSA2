package lib.cli.options.filter.has;

public interface HasFileName {

	String getFileName();
	void setFileName(String fileName);
	
}
