package lib.cli.options.filter.has;

import java.util.Set;

import jacusa.method.rtarrest.RTarrestMethod.RT_READS;

public interface HasApply2reads {

	Set<RT_READS> getApply2Reads();
	
}
