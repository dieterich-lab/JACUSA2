package lib.cli.options.filter.has;

public interface HasFilterDistance {

	int getFilterDistance();
	void setFilterDistance(int distance);
	
}
