package lib.cli.options.filter.has;

import jacusa.io.FileType;

public interface HasFileType {

	FileType getFileType();
	void setFileType(FileType fileType);
	
}
