package lib.cli.options.filter.has;

public interface HasFilterMinRatio {

	double getFilterMinRatio();
	void setFilterMinRatio(double minRatio);
	
}
