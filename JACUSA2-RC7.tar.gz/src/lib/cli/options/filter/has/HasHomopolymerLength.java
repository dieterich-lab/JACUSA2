package lib.cli.options.filter.has;

public interface HasHomopolymerLength {

	int getHomopolymerLength();
	void setHomopolymerLength(int length);
	
}
