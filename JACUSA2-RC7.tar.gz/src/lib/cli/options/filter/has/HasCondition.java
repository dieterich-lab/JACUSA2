package lib.cli.options.filter.has;

public interface HasCondition {

	int getCondition();
	void setCondition(int condition);
	
}
