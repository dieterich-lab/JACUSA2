package lib.cli.options.filter.has;

public interface HasMaxAlleleCount {

	int getMaxAlleleCount();
	void setMaxAlleleCount(int count);
	
}
